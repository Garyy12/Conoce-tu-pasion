package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button regCursante;
    Button regCreador;
    Button buttonIniS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        regCursante = (Button)findViewById(R.id.regCursante);
        regCursante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, creacuenta.class);
                startActivity(i);
            }
        });
        regCreador = (Button)findViewById(R.id.regCreador);
        regCreador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, creacuenta.class);
                startActivity(a);
            }
        });
        buttonIniS = (Button)findViewById(R.id.buttonIniS1);
        buttonIniS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(MainActivity.this, iniciosesion_correo.class);
                startActivity(b);
            }
        });
    }
}