package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class iniciosesion_correo extends AppCompatActivity {
    Button buttonOC;
    Button buttoniniciaS2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciosesion_correo);
        buttoniniciaS2 = (Button)findViewById(R.id.buttonIniS2);
        buttoniniciaS2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(iniciosesion_correo.this, bienvenidoperfil.class);
                startActivity(b);
            }
        });

        buttonOC = (Button)findViewById(R.id.buttonOC);
        buttonOC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(iniciosesion_correo.this, restablecercontra.class);
                startActivity(c);
            }
        });
    }
}