package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class temario extends AppCompatActivity {


    private Spinner mspinner;
    private Spinner mspinner2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temario);

        mspinner= (Spinner) findViewById(R.id.mspinner);
        mspinner2 = (Spinner) findViewById(R.id.mspinner2);

        ArrayList<String> elementos= new ArrayList<>();


        elementos.add("Desplegar u ocultar contenido");
        elementos.add("Submodulo: BIENVENIDA");
        elementos.add("Material de video: Video de bienvenida");
        elementos.add("Material de texto: PDF de bienvenida");
        elementos.add("Submodulo: Preparacion");
        elementos.add("Material de video: Video sobre preparacion");
        elementos.add("Material de texto: PDF de preparacion");
        elementos.add("Submodulo: Etapas de duelo");
        elementos.add("Material e video: Video etapas del duelo");
        elementos.add("Material de texto: PDF etapas del duelo");
        elementos.add("Submodulo:¿Que tan culpable soy yo?");
        elementos.add("Material de video: Video de ¿que tan culpable soy yo?");
        elementos.add("Material de texto: PDF de ¿que tan culpable soy yo?");
        elementos.add("Submodulo: Etapa del anhelo");
        elementos.add("Material de texto: PDF eliminar pensamientos negativos");
        elementos.add("Material de texto: PDF de autoestima");
        elementos.add("Material de video: Video 8, etapa del anhelo");
        elementos.add("Material de video: Video 5, la etapa del anhelo");
        elementos.add("Material de video: Video 4, etapa del anhelo");
        elementos.add("Material de video: Video 3, etapa del anhelo");
        elementos.add("Material de video: Video 2, etapa del anhelo");
        elementos.add("Material de video: Video 6, etapa del anhelo");
        elementos.add("Material de video: Video 1, etapa del anhelo");

        elementos.add("Desplegar u ocultar contenido");
        elementos.add("Submodulo: BIENVENIDA");
        elementos.add("Material de video: Video de bienvenida");
        elementos.add("Material de texto: PDF de bienvenida");
        elementos.add("Submodulo: Preparacion");
        elementos.add("Material de video: Video sobre preparacion");
        elementos.add("Material de texto: PDF de preparacion");
        elementos.add("Submodulo: Etapas de duelo");
        elementos.add("Material e video: Video etapas del duelo");
        elementos.add("Material de texto: PDF etapas del duelo");
        elementos.add("Submodulo:¿Que tan culpable soy yo?");
        elementos.add("Material de video: Video de ¿que tan culpable soy yo?");
        elementos.add("Material de texto: PDF de ¿que tan culpable soy yo?");
        elementos.add("Submodulo: Etapa del anhelo");
        elementos.add("Material de texto: PDF eliminar pensamientos negativos");
        elementos.add("Material de texto: PDF de autoestima");
        elementos.add("Material de video: Video 8, etapa del anhelo");
        elementos.add("Material de video: Video 5, la etapa del anhelo");
        elementos.add("Material de video: Video 4, etapa del anhelo");
        elementos.add("Material de video: Video 3, etapa del anhelo");
        elementos.add("Material de video: Video 2, etapa del anhelo");
        elementos.add("Material de video: Video 6, etapa del anhelo");
        elementos.add("Material de video: Video 1, etapa del anhelo");

        ArrayAdapter adp=new ArrayAdapter(temario.this, android.R.layout.simple_spinner_dropdown_item,elementos);

        mspinner.setAdapter(adp);

        mspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String elemento= (String) mspinner.getAdapter().getItem(i);

                Toast.makeText(temario.this, "Seleccionaste: " +elemento,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}