package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class creacuenta extends AppCompatActivity {
    Button buttonIniS1;
    Button buttonFeli;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creacuenta);
        buttonFeli = (Button)findViewById(R.id.buttonFeli);
        buttonFeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(creacuenta.this, felicidades.class);
                startActivity(a);
            }
        });
        buttonIniS1 = (Button)findViewById(R.id.buttonIniS1);
        buttonIniS1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent g = new Intent(creacuenta.this, iniciosesion_correo.class);
                startActivity(g);
            }
        });
    }
}